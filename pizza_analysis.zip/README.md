<<<<<<< HEAD
In this analysisi we have considered that the ingredients bought one week
expire in a week, so they are not available the following week. We have also
asumed that the profit margin of this business is 15%, the average profit margin
of pizzas in the USA.
=======
# pizza_analysis
>>>>>>> 86b116bdd7f98f3d4ba494aa609ae688a2c8c0cc
